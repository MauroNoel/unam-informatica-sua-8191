// Unidad 5 - Actividad complementaria 2 - Interactividad

// Botón "Ver más": muestra u oculta la información completa de JavaScript
const btnVerMas = document.getElementById('btnVerMas');
const masJavaScript = document.getElementById('masJavaScript');

btnVerMas.addEventListener('click', function () {
  if (masJavaScript.classList.contains('oculto')) {
    masJavaScript.classList.remove('oculto');
    btnVerMas.textContent = 'Ver menos';
  } else {
    masJavaScript.classList.add('oculto');
    btnVerMas.textContent = 'Ver más';
  }
});

// Botón que abre la página principal de la FCA en otra pestaña
const btnFCA = document.getElementById('btnFCA');
btnFCA.addEventListener('click', function () {
  window.open('https://www.fca.unam.mx/', '_blank');
});
